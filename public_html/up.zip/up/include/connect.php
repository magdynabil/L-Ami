<?php $host='localhost';
$root='root';
$password='';
$db_name='up';
$connect=mysqli_connect($host,$root,$password,$db_name);
function close_DB(){ global $connect; mysqli_close($connect); }
?>