<footer class="footer">
    <div class="footer_body">
        <div class="container text-center">
            <div class="row">
                <div class="col-lg-12">
                <h3 class="text-light font-weight-bold" dir="rtl">
                    جميع الحقوق  محفوظة &copy; <script>document.write(new Date().getFullYear());</script>   <a class="text-warning " href="https://www.facebook.com/magdy.nabil.1426/" >  magdy nabil </a><i class="icon-heart" aria-hidden="true"></i>
                </h3>
                </br>
                <h1 class="text-warning font-weight-bold">01023230428</h1>
                <!-- Newsletter -->
                </div>

                <!-- About -->

                <!-- Help & Support -->


                <!-- Privacy -->

            </div>
        </div>
    </div>
    <div class="copyright">
        <div class="container">

            <div class="row">

            </div>
        </div>
    </div>
</footer>